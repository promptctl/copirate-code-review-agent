// Package lifecycle defines the internal lifecycle expression primitives used
// by model.Issue. Callers outside internal/model must use the model package
// hydration, capability, and action APIs instead of importing this package.
//
// Container Progress aggregation is leaf-primitive based: AllOf.Progress folds
// over Progresses(a), which walks through Containers and collects every
// non-Container descendant's Progress. New primitive kinds that need to
// contribute to Progress should be leaf primitives or should implement
// Container so traversal reaches their children. Adding a wrapper primitive
// without Container semantics will make it contribute only its own Progress.
package lifecycle

import (
	"fmt"
	"strings"
)

type State string

const (
	Open       State = "open"
	InProgress State = "in_progress"
	Closed     State = "closed"
)

// Display renders the state for human-readable error messages and CLI output.
// Wire formats and storage continue to use the underscored State value.
func (s State) Display() string {
	switch s {
	case InProgress:
		return "in progress"
	default:
		return string(s)
	}
}

type Progress struct {
	Open       int `json:"open"`
	InProgress int `json:"in_progress"`
	Closed     int `json:"closed"`
	Total      int `json:"total"`
}

type ActionName string

const (
	ActionStart  ActionName = "start"
	ActionDone   ActionName = "done"
	ActionClose  ActionName = "close"
	ActionReopen ActionName = "reopen"

	// [LAW:types-are-the-program] Retention actions complete the sealed set so
	// every legal lifecycle event verb is a named constant, not a raw string.
	ActionArchive   ActionName = "archive"
	ActionUnarchive ActionName = "unarchive"
	ActionDelete    ActionName = "delete"
	ActionRestore   ActionName = "restore"
)

type Lifecycle interface {
	State() State
	Progress() Progress
}

// Container marks lifecycle combinators that own child lifecycle expressions.
// [LAW:one-type-per-behavior] Recursive traversal depends on one container contract instead of ad hoc structural assertions per combinator.
type Container interface {
	Lifecycle
	Children() []Lifecycle
}

// Actionable marks lifecycle expressions a status action can be applied to.
// Apply is total: StatusAction's Target names a real state, a same-state call
// returns the receiver, so there is no error to return. The actor/reason of a
// transition are event provenance owned by the store's write boundary — the
// machine computes the next state and nothing else. [LAW:effects-at-boundaries]
type Actionable interface {
	Lifecycle
	Apply(action StatusAction) Lifecycle
}

// Walk visits the lifecycle tree depth-first. Recursion is the substrate;
// the model package's capability and action APIs deliberately do NOT use
// Walk because they are root-only by policy. Only call Walk when you know
// you want full-tree traversal, such as Progresses for progress aggregation.
// [LAW:dataflow-not-control-flow] Tree traversal is one primitive that receives variable lifecycle data instead of scattering recursive special cases across callers.
func Walk(l Lifecycle, visit func(Lifecycle) bool) {
	if l == nil || !visit(l) {
		return
	}
	if container, ok := l.(Container); ok {
		for _, child := range container.Children() {
			Walk(child, visit)
		}
	}
}

func ParseState(value string) (State, error) {
	normalized := strings.TrimSpace(strings.ToLower(value))
	if normalized == "in-progress" {
		normalized = "in_progress"
	}
	switch State(normalized) {
	case Open, InProgress, Closed:
		return State(normalized), nil
	default:
		return "", fmt.Errorf("invalid status %q (valid: open, in_progress, closed)", value)
	}
}

// DefaultOpen parses a state, defaulting to Open for blank or unrecognized
// input. Use this for lenient boundaries (import, hydration, storage) where
// the data may be absent or legacy. Strict boundaries (CLI flags, query
// language) should use ParseState directly.
func DefaultOpen(value string) State {
	state, err := ParseState(value)
	if err != nil {
		return Open
	}
	return state
}

// ParseAction maps an untrusted action string into the sealed set of all
// eight transition actions.
// [LAW:single-enforcer] The only string-to-ActionName gate; all trust
// boundaries call this instead of carrying their own string comparisons.
func ParseAction(value string) (ActionName, error) {
	normalized := strings.TrimSpace(strings.ToLower(value))
	switch ActionName(normalized) {
	case ActionStart, ActionDone, ActionClose, ActionReopen,
		ActionArchive, ActionUnarchive, ActionDelete, ActionRestore:
		return ActionName(normalized), nil
	default:
		return "", fmt.Errorf("unsupported lifecycle action %q", value)
	}
}

// Progresses collects every non-Container Progress reachable from l by walking
// through Containers. Used by AllOf.Progress to aggregate container progress;
// see the package doc for the leaf-primitive aggregation contract.
func Progresses(l Lifecycle) []Progress {
	out := []Progress{}
	Walk(l, func(current Lifecycle) bool {
		if _, ok := current.(Container); ok {
			return true
		}
		out = append(out, current.Progress())
		return true
	})
	return out
}
