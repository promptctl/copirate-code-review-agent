package workspace

import (
	"context"
	"encoding/json"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestResolveCreatesSharedConfigInGitCommonDir(t *testing.T) {
	repo := t.TempDir()
	run(t, repo, "git", "init")
	info, err := Resolve(repo)
	if err != nil {
		t.Fatalf("Resolve() error = %v", err)
	}
	if info.WorkspaceID == "" {
		t.Fatal("expected workspace ID")
	}
	if info.IssuePrefix.Value() == "" {
		t.Fatal("expected issue prefix")
	}
	if !info.IssuePrefix.Derived() {
		t.Fatal("first resolve mints the prefix from the repo name; provenance must say derived")
	}
	if _, err := os.Stat(info.ConfigPath); err != nil {
		t.Fatalf("config file missing: %v", err)
	}
	if _, err := os.Stat(info.StorageDir); err != nil {
		t.Fatalf("storage dir missing: %v", err)
	}
	common := strings.TrimSpace(runOutput(t, repo, "git", "rev-parse", "--git-common-dir"))
	wantStorageDir, err := filepath.EvalSymlinks(filepath.Join(repo, common, "links"))
	if err != nil {
		t.Fatalf("EvalSymlinks(wantStorageDir) error = %v", err)
	}
	gotStorageDir, err := filepath.EvalSymlinks(info.StorageDir)
	if err != nil {
		t.Fatalf("EvalSymlinks(gotStorageDir) error = %v", err)
	}
	if gotStorageDir != wantStorageDir {
		t.Fatalf("storage dir = %q, want %q", info.StorageDir, wantStorageDir)
	}
	info2, err := Resolve(repo)
	if err != nil {
		t.Fatalf("Resolve second call error = %v", err)
	}
	if info2.WorkspaceID != info.WorkspaceID {
		t.Fatalf("workspace ID changed: %q != %q", info2.WorkspaceID, info.WorkspaceID)
	}
	if info2.IssuePrefix.Value() != info.IssuePrefix.Value() {
		t.Fatalf("issue prefix changed: %q != %q", info2.IssuePrefix.Value(), info.IssuePrefix.Value())
	}
	// Provenance is per-load: the derived value was persisted, so the second
	// resolve reads it back as configured.
	if info2.IssuePrefix.Derived() {
		t.Fatal("second resolve reads the persisted prefix; provenance must say configured")
	}
}

func TestResolveFromSubdirIsCwdDepthIndependent(t *testing.T) {
	repo := t.TempDir()
	run(t, repo, "git", "init")
	sub := filepath.Join(repo, "nested", "deeper")
	if err := os.MkdirAll(sub, 0o755); err != nil {
		t.Fatalf("MkdirAll(sub) error = %v", err)
	}

	fromRoot, err := Resolve(repo)
	if err != nil {
		t.Fatalf("Resolve(repo) error = %v", err)
	}
	fromSub, err := Resolve(sub)
	if err != nil {
		t.Fatalf("Resolve(sub) error = %v", err)
	}

	// The store belongs to the repository, not to how deep lit was invoked. A
	// relative --git-common-dir ("../.git" from a subdir) joined against the
	// toplevel climbs out of the repo and resolves a different store; absolute
	// resolution must yield the same store from any depth.
	if fromSub.StorageDir != fromRoot.StorageDir {
		t.Fatalf("storage dir depends on cwd depth: subdir=%q root=%q", fromSub.StorageDir, fromRoot.StorageDir)
	}
	if fromSub.WorkspaceID != fromRoot.WorkspaceID {
		t.Fatalf("workspace id depends on cwd depth: subdir=%q root=%q", fromSub.WorkspaceID, fromRoot.WorkspaceID)
	}
	wantStorageDir, err := filepath.EvalSymlinks(filepath.Join(repo, ".git", "links"))
	if err != nil {
		t.Fatalf("EvalSymlinks(want) error = %v", err)
	}
	gotStorageDir, err := filepath.EvalSymlinks(fromSub.StorageDir)
	if err != nil {
		t.Fatalf("EvalSymlinks(got) error = %v", err)
	}
	if gotStorageDir != wantStorageDir {
		t.Fatalf("subdir storage dir = %q, want repo-local %q", gotStorageDir, wantStorageDir)
	}
}

func TestResolveYieldsOnePhysicalStorePerSpelling(t *testing.T) {
	// A repo reached through a symlinked ancestor (the macOS /var -> /private/var
	// shape, reproduced portably with an explicit symlink) must resolve to the
	// same physical store as the unlinked path. Two spellings of one store make
	// the dolt driver hand the second opener a read-only handle, so Resolve must
	// collapse both to the physical DatabasePath.
	physical := t.TempDir()
	run(t, physical, "git", "init")

	link := filepath.Join(t.TempDir(), "link")
	if err := os.Symlink(physical, link); err != nil {
		t.Skipf("symlink unsupported: %v", err)
	}

	viaPhysical, err := Resolve(physical)
	if err != nil {
		t.Fatalf("Resolve(physical) error = %v", err)
	}
	viaLink, err := Resolve(link)
	if err != nil {
		t.Fatalf("Resolve(link) error = %v", err)
	}

	if viaLink.DatabasePath != viaPhysical.DatabasePath {
		t.Fatalf("symlinked spelling resolved a different store: link=%q physical=%q",
			viaLink.DatabasePath, viaPhysical.DatabasePath)
	}
	if resolved, err := filepath.EvalSymlinks(viaLink.StorageDir); err != nil || resolved != viaLink.StorageDir {
		t.Fatalf("StorageDir %q is not already canonical (resolved=%q err=%v)",
			viaLink.StorageDir, resolved, err)
	}
}

// TestClassifyGitError pins the git-error classification the repo gates share:
// git exiting non-zero of its own accord is the ErrNotGitRepo sentinel, while a
// binary that cannot run or a process killed by a signal is surfaced, not
// silently treated as "not a repository". The three cases are produced by real
// exec failures rather than fabricated errors, so the test exercises the exact
// error shapes production sees.
func TestClassifyGitError(t *testing.T) {
	// git's fatal exit code (128) — what rev-parse returns for "not a
	// repository" / "not a work tree": the legitimate sentinel case.
	fatalExit := exec.Command("sh", "-c", "exit 128").Run()
	if got := classifyGitError("probe", fatalExit); got != ErrNotGitRepo {
		t.Fatalf("classifyGitError(exit 128) = %v, want ErrNotGitRepo sentinel", got)
	}

	// A non-128 exit is NOT "not a repository" — it must surface, not be skipped.
	otherExit := exec.Command("sh", "-c", "exit 3").Run()
	if got := classifyGitError("probe", otherExit); got == nil || got == ErrNotGitRepo {
		t.Fatalf("classifyGitError(exit 3) = %v, want a surfaced error", got)
	}

	// Binary not found — infrastructure failure, must surface (not the sentinel).
	notFound := exec.Command("lit-no-such-binary-xyzzy").Run()
	if got := classifyGitError("probe", notFound); got == nil || got == ErrNotGitRepo {
		t.Fatalf("classifyGitError(not found) = %v, want a surfaced error", got)
	}

	// Killed by a signal — ExitCode() is -1, must surface, not skip as "no repo".
	signaled := exec.Command("sh", "-c", "kill -TERM $$").Run()
	if got := classifyGitError("probe", signaled); got == nil || got == ErrNotGitRepo {
		t.Fatalf("classifyGitError(signal) = %v, want a surfaced error", got)
	}
}

func TestResolveFailsOutsideGit(t *testing.T) {
	_, err := Resolve(t.TempDir())
	if err == nil {
		t.Fatal("expected error")
	}
	if err != ErrNotGitRepo {
		t.Fatalf("err = %v, want %v", err, ErrNotGitRepo)
	}
}

func TestResolveNormalizesConfiguredIssuePrefix(t *testing.T) {
	repo := t.TempDir()
	run(t, repo, "git", "init")

	info, err := Resolve(repo)
	if err != nil {
		t.Fatalf("Resolve() initial error = %v", err)
	}

	rewriteConfigPrefix(t, info.ConfigPath, "Renderer Platform Team")

	info, err = Resolve(repo)
	if err != nil {
		t.Fatalf("Resolve() normalized error = %v", err)
	}
	if info.IssuePrefix.Value() != "renderer-pla" {
		t.Fatalf("IssuePrefix = %q, want renderer-pla", info.IssuePrefix.Value())
	}
	if info.IssuePrefix.Derived() {
		t.Fatal("a configured prefix that only needed normalization is not derived")
	}
}

func TestResolveDerivesPrefixWhenConfigValueAbsent(t *testing.T) {
	repo := t.TempDir()
	run(t, repo, "git", "init")

	info, err := Resolve(repo)
	if err != nil {
		t.Fatalf("Resolve() initial error = %v", err)
	}
	rewriteConfigPrefix(t, info.ConfigPath, "   ")

	derivedInfo, err := Resolve(repo)
	if err != nil {
		t.Fatalf("Resolve() after blanking prefix error = %v", err)
	}
	if derivedInfo.IssuePrefix.Value() == "" {
		t.Fatal("expected a derived issue prefix")
	}
	if !derivedInfo.IssuePrefix.Derived() {
		t.Fatal("an absent configured prefix must resolve with derived provenance")
	}

	// The derivation is persisted, not repeated silently on every load.
	payload, err := os.ReadFile(info.ConfigPath)
	if err != nil {
		t.Fatalf("ReadFile(config) error = %v", err)
	}
	var cfg Config
	if err := json.Unmarshal(payload, &cfg); err != nil {
		t.Fatalf("json.Unmarshal(config) error = %v", err)
	}
	if cfg.IssuePrefix != derivedInfo.IssuePrefix.Value() {
		t.Fatalf("persisted prefix = %q, want %q", cfg.IssuePrefix, derivedInfo.IssuePrefix.Value())
	}
}

func TestResolveRejectsInvalidConfiguredPrefix(t *testing.T) {
	repo := t.TempDir()
	run(t, repo, "git", "init")

	info, err := Resolve(repo)
	if err != nil {
		t.Fatalf("Resolve() initial error = %v", err)
	}
	rewriteConfigPrefix(t, info.ConfigPath, "ab")

	// Only an absent prefix falls back to derivation; an invalid configured
	// value is a loud error, never silently replaced.
	if _, err := Resolve(repo); err == nil || !strings.Contains(err.Error(), "invalid issue_prefix") {
		t.Fatalf("Resolve() error = %v, want invalid issue_prefix", err)
	}
}

func rewriteConfigPrefix(t *testing.T, configPath string, prefix string) {
	t.Helper()
	payload, err := os.ReadFile(configPath)
	if err != nil {
		t.Fatalf("ReadFile(config) error = %v", err)
	}
	var cfg Config
	if err := json.Unmarshal(payload, &cfg); err != nil {
		t.Fatalf("json.Unmarshal(config) error = %v", err)
	}
	cfg.IssuePrefix = prefix
	updated, err := json.Marshal(cfg)
	if err != nil {
		t.Fatalf("json.Marshal(config) error = %v", err)
	}
	if err := os.WriteFile(configPath, updated, 0o644); err != nil {
		t.Fatalf("WriteFile(config) error = %v", err)
	}
}

func TestGitRemotesReturnsFetchURLsSortedByName(t *testing.T) {
	repo := t.TempDir()
	run(t, repo, "git", "init")
	run(t, repo, "git", "remote", "add", "upstream", "https://github.com/acme/upstream.git")
	run(t, repo, "git", "remote", "add", "origin", "https://github.com/acme/origin.git")
	run(t, repo, "git", "remote", "set-url", "--push", "origin", "git@github.com:acme/origin.git")

	remotes, err := GitRemotes(context.Background(), repo)
	if err != nil {
		t.Fatalf("GitRemotes() error = %v", err)
	}
	if len(remotes) != 2 {
		t.Fatalf("len(remotes) = %d, want 2", len(remotes))
	}
	if remotes[0].Name != "origin" || remotes[0].URL != "https://github.com/acme/origin.git" {
		t.Fatalf("origin remote mismatch: %+v", remotes[0])
	}
	if remotes[1].Name != "upstream" || remotes[1].URL != "https://github.com/acme/upstream.git" {
		t.Fatalf("upstream remote mismatch: %+v", remotes[1])
	}
}

func TestDefaultRemoteBranchFromSymbolicRef(t *testing.T) {
	branch := defaultRemoteBranchFromSymbolicRef("origin", "origin/master")
	if branch != "master" {
		t.Fatalf("defaultRemoteBranchFromSymbolicRef() = %q, want master", branch)
	}
	if got := defaultRemoteBranchFromSymbolicRef("origin", "upstream/master"); got != "" {
		t.Fatalf("defaultRemoteBranchFromSymbolicRef() = %q, want empty", got)
	}
}

func TestDefaultRemoteBranchFromLSRemote(t *testing.T) {
	output := "ref: refs/heads/master\tHEAD\nc0ffee\tHEAD\n"
	if got := defaultRemoteBranchFromLSRemote(output); got != "master" {
		t.Fatalf("defaultRemoteBranchFromLSRemote() = %q, want master", got)
	}
	if got := defaultRemoteBranchFromLSRemote("c0ffee\trefs/heads/master\n"); got != "" {
		t.Fatalf("defaultRemoteBranchFromLSRemote() = %q, want empty", got)
	}
}

func TestDefaultRemoteBranchUsesRemoteHeadAdvertisement(t *testing.T) {
	repo := t.TempDir()
	remote := filepath.Join(t.TempDir(), "remote.git")
	run(t, repo, "git", "init")
	run(t, repo, "git", "checkout", "-b", "master")
	if err := os.WriteFile(filepath.Join(repo, "README.md"), []byte("test\n"), 0o644); err != nil {
		t.Fatalf("WriteFile(README.md) error = %v", err)
	}
	run(t, repo, "git", "add", "README.md")
	run(t, repo, "git", "-c", "user.name=Test", "-c", "user.email=test@example.com", "commit", "-m", "init")
	run(t, repo, "git", "init", "--bare", remote)
	run(t, repo, "git", "remote", "add", "origin", remote)
	run(t, repo, "git", "push", "-u", "origin", "master")
	run(t, repo, "git", "--git-dir", remote, "symbolic-ref", "HEAD", "refs/heads/master")

	got := DefaultRemoteBranch(context.Background(), repo, "origin")
	if got != "master" {
		t.Fatalf("DefaultRemoteBranch() = %q, want master", got)
	}
}

func TestRemoteHasRefsReturnsFalseForEmptyBareRemote(t *testing.T) {
	repo := t.TempDir()
	remote := filepath.Join(t.TempDir(), "remote.git")
	run(t, repo, "git", "init")
	run(t, repo, "git", "init", "--bare", remote)
	run(t, repo, "git", "remote", "add", "origin", remote)

	hasRefs, err := RemoteHasRefs(context.Background(), repo, "origin")
	if err != nil {
		t.Fatalf("RemoteHasRefs() error = %v, want nil for empty bare remote", err)
	}
	if hasRefs {
		t.Fatalf("RemoteHasRefs() = true, want false for empty bare remote")
	}
}

func TestRemoteHasRefsReturnsTrueForPopulatedRemote(t *testing.T) {
	repo := t.TempDir()
	remote := filepath.Join(t.TempDir(), "remote.git")
	run(t, repo, "git", "init")
	run(t, repo, "git", "checkout", "-b", "master")
	if err := os.WriteFile(filepath.Join(repo, "README.md"), []byte("test\n"), 0o644); err != nil {
		t.Fatalf("WriteFile(README.md) error = %v", err)
	}
	run(t, repo, "git", "add", "README.md")
	run(t, repo, "git", "-c", "user.name=Test", "-c", "user.email=test@example.com", "commit", "-m", "init")
	run(t, repo, "git", "init", "--bare", remote)
	run(t, repo, "git", "remote", "add", "origin", remote)
	run(t, repo, "git", "push", "-u", "origin", "master")

	hasRefs, err := RemoteHasRefs(context.Background(), repo, "origin")
	if err != nil {
		t.Fatalf("RemoteHasRefs() error = %v, want nil for populated remote", err)
	}
	if !hasRefs {
		t.Fatalf("RemoteHasRefs() = false, want true for populated remote")
	}
}

func TestRemoteHasRefsReturnsErrorForUnknownRemoteName(t *testing.T) {
	repo := t.TempDir()
	run(t, repo, "git", "init")

	hasRefs, err := RemoteHasRefs(context.Background(), repo, "does-not-exist")
	if err == nil {
		t.Fatalf("RemoteHasRefs() error = nil, want error for unknown remote (got hasRefs=%v)", hasRefs)
	}
	if hasRefs {
		t.Fatalf("RemoteHasRefs() = true, want false alongside error")
	}
}

// TestGitOutputCancellationKillsSubprocess pins gitOutput's load-bearing contract:
// a cancelled context kills the git subprocess promptly instead of letting a
// network-wedged call hang. It is the unit-level counterpart to cmd/lit's
// end-to-end SIGTERM acceptance test — the mechanism (exec.CommandContext) lives
// here, so it is verified here directly. [LAW:verifiable-goals]
//
// The remote is a black-hole TCP listener: it accepts git's connection and never
// answers the ref advertisement, so `git ls-remote` blocks in git itself — no
// transport subprocess, so cancelling the context kills git and unblocks its
// stdout read at once (an ext-transport hang would leave a grandchild holding the
// pipe and hide the very behavior under test).
func TestGitOutputCancellationKillsSubprocess(t *testing.T) {
	if _, err := exec.LookPath("git"); err != nil {
		t.Skip("git not available")
	}
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen for black-hole remote: %v", err)
	}
	defer ln.Close()
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				return // listener closed
			}
			// Hold the connection open and never write the git ref advertisement.
			t.Cleanup(func() { _ = conn.Close() })
		}
	}()
	url := "git://127.0.0.1:" + strconv.Itoa(ln.Addr().(*net.TCPAddr).Port) + "/wedge.git"

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() {
		_, gitErr := gitOutput(ctx, t.TempDir(), "ls-remote", url)
		done <- gitErr
	}()

	// It must actually hang: still running after a settle window. If it returned
	// already, the wedge never engaged and the cancellation assertion is meaningless.
	select {
	case err := <-done:
		t.Fatalf("gitOutput returned before cancellation (%v) — the black-hole remote did not wedge git", err)
	case <-time.After(1 * time.Second):
	}

	cancel()
	select {
	case err := <-done:
		// A killed subprocess must surface as an error, never a silent empty success.
		if err == nil {
			t.Fatalf("gitOutput returned nil error after cancellation; want a non-nil error")
		}
	case <-time.After(3 * time.Second):
		t.Fatalf("gitOutput did not return within 3s of cancellation — exec.CommandContext did not kill the wedged git")
	}
}

// TestRemoteHasDoltDataFalseForCodeOnlyRemote is the distinction that makes the
// adopt decision honest: a normal code remote has git refs (RemoteHasRefs is
// true) but carries no lit ticket data, so RemoteHasDoltData must be false. This
// is what lets init tell "remote is just a code repo" apart from "remote has a
// backlog we failed to adopt".
func TestRemoteHasDoltDataFalseForCodeOnlyRemote(t *testing.T) {
	repo := t.TempDir()
	remote := filepath.Join(t.TempDir(), "remote.git")
	run(t, repo, "git", "init")
	run(t, repo, "git", "checkout", "-b", "master")
	if err := os.WriteFile(filepath.Join(repo, "README.md"), []byte("test\n"), 0o644); err != nil {
		t.Fatalf("WriteFile(README.md) error = %v", err)
	}
	run(t, repo, "git", "add", "README.md")
	run(t, repo, "git", "-c", "user.name=Test", "-c", "user.email=test@example.com", "commit", "-m", "init")
	run(t, repo, "git", "init", "--bare", remote)
	run(t, repo, "git", "remote", "add", "origin", remote)
	run(t, repo, "git", "push", "-u", "origin", "master")

	hasRefs, err := RemoteHasRefs(context.Background(), repo, "origin")
	if err != nil || !hasRefs {
		t.Fatalf("precondition: RemoteHasRefs() = %v, err = %v; want true,nil", hasRefs, err)
	}
	hasData, err := RemoteHasDoltData(context.Background(), repo, "origin")
	if err != nil {
		t.Fatalf("RemoteHasDoltData() error = %v, want nil", err)
	}
	if hasData {
		t.Fatalf("RemoteHasDoltData() = true for a code-only remote, want false")
	}
}

// TestRemoteHasDoltDataTrueWhenDoltRefPresent confirms the refs/dolt/* namespace
// is what RemoteHasDoltData keys on.
func TestRemoteHasDoltDataTrueWhenDoltRefPresent(t *testing.T) {
	repo := t.TempDir()
	remote := filepath.Join(t.TempDir(), "remote.git")
	run(t, repo, "git", "init")
	run(t, repo, "git", "checkout", "-b", "master")
	if err := os.WriteFile(filepath.Join(repo, "README.md"), []byte("test\n"), 0o644); err != nil {
		t.Fatalf("WriteFile(README.md) error = %v", err)
	}
	run(t, repo, "git", "add", "README.md")
	run(t, repo, "git", "-c", "user.name=Test", "-c", "user.email=test@example.com", "commit", "-m", "init")
	run(t, repo, "git", "init", "--bare", remote)
	run(t, repo, "git", "remote", "add", "origin", remote)
	// Mirror how lit's sync lands data: a ref under the refs/dolt/* namespace.
	run(t, repo, "git", "push", "origin", "HEAD:refs/dolt/data")

	hasData, err := RemoteHasDoltData(context.Background(), repo, "origin")
	if err != nil {
		t.Fatalf("RemoteHasDoltData() error = %v, want nil", err)
	}
	if !hasData {
		t.Fatalf("RemoteHasDoltData() = false when refs/dolt/data is present, want true")
	}
}

func TestUpstreamRemoteFromRef(t *testing.T) {
	if got := upstreamRemoteFromRef("origin/master"); got != "origin" {
		t.Fatalf("upstreamRemoteFromRef() = %q, want origin", got)
	}
	if got := upstreamRemoteFromRef("upstream/master"); got != "upstream" {
		t.Fatalf("upstreamRemoteFromRef() = %q, want upstream", got)
	}
	if got := upstreamRemoteFromRef("master"); got != "" {
		t.Fatalf("upstreamRemoteFromRef() = %q, want empty", got)
	}
}

func run(t *testing.T, dir string, name string, args ...string) {
	t.Helper()
	cmd := exec.Command(name, args...)
	cmd.Dir = dir
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("%s %v failed: %v\n%s", name, args, err, string(out))
	}
}

func runOutput(t *testing.T, dir string, name string, args ...string) string {
	t.Helper()
	cmd := exec.Command(name, args...)
	cmd.Dir = dir
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("%s %v failed: %v\n%s", name, args, err, string(out))
	}
	return strings.TrimSpace(string(out))
}
