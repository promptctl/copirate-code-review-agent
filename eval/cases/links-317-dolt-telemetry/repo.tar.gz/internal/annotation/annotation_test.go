package annotation

import (
	"context"
	"encoding/json"
	"errors"
	"testing"

	"github.com/promptctl/links-issue-tracker/internal/model"
)

func TestKindStringReturnsKey(t *testing.T) {
	if MissingField.String() != "missing_field" {
		t.Fatalf("MissingField.String() = %q, want missing_field", MissingField.String())
	}
	if OpenDependency.String() != "open_dependency" {
		t.Fatalf("OpenDependency.String() = %q, want open_dependency", OpenDependency.String())
	}
}

// TestEveryRegisteredKindHasReadinessRole pins the construction-time invariant:
// register refuses a kind with no readiness role, so every kind the registry
// produced carries a valid (non-zero) classification. This is the guard against
// a kind ever silently defaulting to "ready" — the disposition is mandatory at
// the birth site, not a side-list a consumer keeps in sync.
func TestEveryRegisteredKindHasReadinessRole(t *testing.T) {
	kinds := Kinds()
	if len(kinds) == 0 {
		t.Fatal("Kinds() returned no registered kinds")
	}
	for _, k := range kinds {
		if k.ReadinessRole() == roleInvalid {
			t.Errorf("kind %q has no readiness role", k.String())
		}
	}
}

// TestKindsExcludesAliases pins that Kinds() enumerates only canonical kinds —
// the "blocked_by" deserialization alias resolves to OpenDependency but is not
// itself a kind, so it must not appear as a distinct entry.
func TestKindsExcludesAliases(t *testing.T) {
	for _, k := range Kinds() {
		if k.String() == "blocked_by" {
			t.Fatal("Kinds() must not include the blocked_by alias as a distinct kind")
		}
	}
	parsed, ok := parseKind("blocked_by")
	if !ok || parsed != OpenDependency {
		t.Fatalf("blocked_by must still resolve to OpenDependency, got (%v, %v)", parsed, ok)
	}
}

func TestKindJSONRoundTrip(t *testing.T) {
	original := MissingField
	data, err := json.Marshal(original)
	if err != nil {
		t.Fatalf("json.Marshal(MissingField) error = %v", err)
	}
	if string(data) != `"missing_field"` {
		t.Fatalf("json.Marshal(MissingField) = %s, want %q", data, "missing_field")
	}
	var recovered Kind
	if err := json.Unmarshal(data, &recovered); err != nil {
		t.Fatalf("json.Unmarshal() error = %v", err)
	}
	if recovered != original {
		t.Fatalf("round-trip kind = %#v, want %#v", recovered, original)
	}
}

func TestKindMarshalJSONRejectsInvalidKind(t *testing.T) {
	var invalid Kind
	if _, err := json.Marshal(invalid); err == nil {
		t.Fatal("json.Marshal(invalid Kind) expected error")
	}
}

func TestKindUnmarshalJSONRejectsUnknownKind(t *testing.T) {
	var recovered Kind
	err := json.Unmarshal([]byte(`"unknown_kind"`), &recovered)
	if err == nil {
		t.Fatal("json.Unmarshal(unknown kind) expected error")
	}
	if err.Error() != `unknown annotation kind "unknown_kind"` {
		t.Fatalf("json.Unmarshal(unknown kind) error = %q", err.Error())
	}
}

func TestAnnotateRunsAllAnnotators(t *testing.T) {
	ctx := context.Background()
	issues := []model.Issue{
		{ID: "a", Description: ""},
		{ID: "b", Description: "has desc"},
	}
	descChecker := func(_ context.Context, issue model.Issue) ([]Annotation, error) {
		if issue.Description == "" {
			return []Annotation{{Kind: MissingField, Message: "description"}}, nil
		}
		return nil, nil
	}
	alwaysAnnotates := func(_ context.Context, _ model.Issue) ([]Annotation, error) {
		return []Annotation{{Kind: OpenDependency, Message: "lit-xyz"}}, nil
	}

	result, err := Annotate(ctx, issues, descChecker, alwaysAnnotates)
	if err != nil {
		t.Fatalf("Annotate() error = %v", err)
	}
	if len(result) != 2 {
		t.Fatalf("len(result) = %d, want 2", len(result))
	}
	// Issue "a": missing description + blocked = 2 annotations
	if len(result[0].Annotations) != 2 {
		t.Fatalf("result[0].Annotations = %d, want 2", len(result[0].Annotations))
	}
	// Issue "b": only blocked = 1 annotation
	if len(result[1].Annotations) != 1 {
		t.Fatalf("result[1].Annotations = %d, want 1", len(result[1].Annotations))
	}
	if result[1].Annotations[0].Kind.String() != "open_dependency" {
		t.Fatalf("result[1].Annotations[0].Kind = %q, want open_dependency", result[1].Annotations[0].Kind.String())
	}
}

func TestAnnotateEmptyAnnotatorsProducesEmptySlice(t *testing.T) {
	ctx := context.Background()
	issues := []model.Issue{{ID: "a"}}

	result, err := Annotate(ctx, issues)
	if err != nil {
		t.Fatalf("Annotate() error = %v", err)
	}
	if result[0].Annotations == nil {
		t.Fatal("Annotations should be empty slice, not nil")
	}
	if len(result[0].Annotations) != 0 {
		t.Fatalf("len(Annotations) = %d, want 0", len(result[0].Annotations))
	}
}

func TestAnnotateAnnotatorError(t *testing.T) {
	ctx := context.Background()
	issues := []model.Issue{{ID: "a"}}
	failing := func(_ context.Context, _ model.Issue) ([]Annotation, error) {
		return nil, errors.New("lookup failed")
	}

	_, err := Annotate(ctx, issues, failing)
	if err == nil {
		t.Fatal("Annotate() expected error")
	}
	if err.Error() != "lookup failed" {
		t.Fatalf("error = %q, want %q", err.Error(), "lookup failed")
	}
}

func TestAnnotatedIssueJSONShape(t *testing.T) {
	issue, err := model.HydrateStatus(model.Issue{
		ID:        "lit-abc",
		Title:     "Test issue",
		IssueType: "task",
	}, model.StatusView{Value: model.StateOpen})
	if err != nil {
		t.Fatalf("HydrateStatus() error = %v", err)
	}
	ai := AnnotatedIssue{
		Issue: issue,
		Annotations: []Annotation{
			{Kind: MissingField, Message: "description"},
		},
	}
	data, err := json.Marshal(ai)
	if err != nil {
		t.Fatalf("json.Marshal() error = %v", err)
	}
	var raw map[string]json.RawMessage
	if err := json.Unmarshal(data, &raw); err != nil {
		t.Fatalf("json.Unmarshal() error = %v", err)
	}
	// Issue fields should be at top level (embedded)
	if _, ok := raw["id"]; !ok {
		t.Fatal("JSON missing top-level 'id' field")
	}
	if _, ok := raw["title"]; !ok {
		t.Fatal("JSON missing top-level 'title' field")
	}
	// Annotations should be present
	if _, ok := raw["annotations"]; !ok {
		t.Fatal("JSON missing 'annotations' field")
	}
	// Should NOT have a nested "issue" key
	if _, ok := raw["issue"]; ok {
		t.Fatal("JSON should not have nested 'issue' key — Issue should be embedded")
	}
}

func TestHasAnyMatchesKind(t *testing.T) {
	annotations := []Annotation{
		{Kind: MissingField, Message: "description"},
		{Kind: OpenDependency, Message: "lit-xyz"},
	}
	if !HasAny(annotations, OpenDependency) {
		t.Fatal("HasAny should match OpenDependency")
	}
	if !HasAny(annotations, MissingField, OpenDependency) {
		t.Fatal("HasAny should match with multiple kinds")
	}
}

func TestHasAnyNoMatch(t *testing.T) {
	annotations := []Annotation{
		{Kind: MissingField, Message: "description"},
	}
	if HasAny(annotations, OpenDependency) {
		t.Fatal("HasAny should not match OpenDependency when only MissingField present")
	}
}

func TestHasAnyEmptyAnnotations(t *testing.T) {
	if HasAny([]Annotation{}, MissingField) {
		t.Fatal("HasAny on empty annotations should return false")
	}
	if HasAny(nil, MissingField) {
		t.Fatal("HasAny on nil annotations should return false")
	}
}
