package cli

import (
	"bytes"
	"context"
	"strings"
	"testing"

	"github.com/promptctl/links-issue-tracker/internal/model"
	"github.com/promptctl/links-issue-tracker/internal/store"
)

func TestRunFollowupParentsToClosedTicket(t *testing.T) {
	ctx := context.Background()
	ap := newTestCLIApp(t)

	parent, err := ap.Store.CreateIssue(ctx, store.CreateIssueInput{Prefix: "test",
		Title:     "Renderer cache invalidation",
		Topic:     "renderer",
		IssueType: "task",
		Priority:  0,
	})
	if err != nil {
		t.Fatalf("CreateIssue(parent) error = %v", err)
	}
	if _, err := ap.Store.Apply(ctx, parent.ID, store.Change{Action: model.Start{Assignee: "tester"}, Actor: "tester"}); err != nil {
		t.Fatalf("StartIssue error = %v", err)
	}
	if _, err := ap.Store.Apply(ctx, parent.ID, store.Change{Action: model.Done{}, Actor: "tester"}); err != nil {
		t.Fatalf("Apply(done) error = %v", err)
	}

	var stdout bytes.Buffer
	if err := runFollowup(ctx, &stdout, ap, []string{
		"--on", parent.ID,
		"--title", "Surface stale cache rows in doctor",
	}); err != nil {
		t.Fatalf("runFollowup() error = %v", err)
	}

	createdID := firstIssueID(t, stdout.String())
	if createdID != parent.ID+".1" {
		t.Fatalf("created.ID = %q, want %q", createdID, parent.ID+".1")
	}
	created, err := ap.Store.GetIssue(ctx, createdID)
	if err != nil {
		t.Fatalf("GetIssue(%s) error = %v", createdID, err)
	}
	if created.Topic != parent.Topic {
		t.Fatalf("created.Topic = %q, want inherited %q", created.Topic, parent.Topic)
	}
	if !strings.Contains(created.Description, parent.ID) {
		t.Fatalf("created.Description = %q, want reference to parent %q", created.Description, parent.ID)
	}
	if created.IssueType != "task" {
		t.Fatalf("created.IssueType = %q, want task", created.IssueType)
	}
}

func TestRunFollowupRespectsExplicitOverrides(t *testing.T) {
	ctx := context.Background()
	ap := newTestCLIApp(t)

	parent, err := ap.Store.CreateIssue(ctx, store.CreateIssueInput{Prefix: "test",
		Title:     "Sync flow tightening",
		Topic:     "sync",
		IssueType: "task",
		Priority:  0,
	})
	if err != nil {
		t.Fatalf("CreateIssue(parent) error = %v", err)
	}

	var stdout bytes.Buffer
	if err := runFollowup(ctx, &stdout, ap, []string{
		"--on", parent.ID,
		"--title", "Add sync metrics surface",
		"--description", "Custom description for the follow-up.",
		"--topic", "observability",
		"--type", "feature",
		"--priority", "1",
		"--labels", "metrics,observability",
	}); err != nil {
		t.Fatalf("runFollowup() error = %v", err)
	}

	created, err := ap.Store.GetIssue(ctx, firstIssueID(t, stdout.String()))
	if err != nil {
		t.Fatalf("GetIssue() error = %v", err)
	}
	if created.Topic != "observability" {
		t.Fatalf("created.Topic = %q, want observability", created.Topic)
	}
	if created.Description != "Custom description for the follow-up." {
		t.Fatalf("created.Description = %q, want explicit override", created.Description)
	}
	if created.IssueType != "feature" {
		t.Fatalf("created.IssueType = %q, want feature", created.IssueType)
	}
	if created.Priority != 1 {
		t.Fatalf("created.Priority = %d, want 1", created.Priority)
	}
}

func TestRunFollowupRequiresOnAndTitle(t *testing.T) {
	ctx := context.Background()
	ap := newTestCLIApp(t)

	cases := []struct {
		name string
		args []string
	}{
		{"missing --on", []string{"--title", "x"}},
		{"missing --title", []string{"--on", "test-aaaaaaaa-bbbbbbbb"}},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			var stdout bytes.Buffer
			if err := runFollowup(ctx, &stdout, ap, c.args); err == nil {
				t.Fatalf("runFollowup() expected usage error, got nil")
			}
		})
	}
}

func TestRunFollowupUnknownParentReturnsError(t *testing.T) {
	ctx := context.Background()
	ap := newTestCLIApp(t)

	var stdout bytes.Buffer
	err := runFollowup(ctx, &stdout, ap, []string{
		"--on", "test-deadbeef-cafef00d",
		"--title", "Phantom follow-up",
	})
	if err == nil {
		t.Fatalf("runFollowup() expected error for unknown parent, got nil")
	}
}

func TestRunFollowupWithoutAssigneeCreatesUnassigned(t *testing.T) {
	t.Setenv("CLAUDE_CODE_SESSION_ID", "sess-closer")
	ctx := context.Background()
	ap := newTestCLIApp(t)
	parent, err := ap.Store.CreateIssue(ctx, store.CreateIssueInput{Prefix: "test",
		Title: "Closed work", Topic: "lifecycle", IssueType: "task", Priority: 0,
	})
	if err != nil {
		t.Fatalf("CreateIssue(parent) error = %v", err)
	}
	var stdout bytes.Buffer
	if err := runFollowup(ctx, &stdout, ap, []string{
		"--on", parent.ID, "--title", "Surfaced follow-up",
	}); err != nil {
		t.Fatalf("runFollowup() error = %v", err)
	}
	created, err := ap.Store.GetIssue(ctx, firstIssueID(t, stdout.String()))
	if err != nil {
		t.Fatalf("GetIssue() error = %v", err)
	}
	if got := created.AssigneeValue(); got != "" {
		t.Fatalf("created.AssigneeValue() = %q, want empty: followup capture is not a claim", got)
	}
}
