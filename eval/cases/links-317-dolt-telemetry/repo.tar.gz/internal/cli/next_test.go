package cli

import (
	"bytes"
	"strings"
	"testing"

	"github.com/promptctl/links-issue-tracker/internal/annotation"
	"github.com/promptctl/links-issue-tracker/internal/model"
	"github.com/promptctl/links-issue-tracker/internal/store"
)

// runNextRow reproduces exactly what `lit next` picks — the shared workable
// pipeline, the optional --continue bias, and the first-ready pick — and returns
// the chosen annotated row. With --json removed this probes the command's
// selection logic against real domain values rather than a parsed line.
// [LAW:single-enforcer]
func (h readyTestHarness) runNextRow(continueBias bool) annotation.AnnotatedIssue {
	h.t.Helper()
	annotated, details, err := gatherWorkableAnnotated(h.ctx, h.ap, workableFilter{})
	if err != nil {
		h.t.Fatalf("gatherWorkableAnnotated error = %v", err)
	}
	if continueBias {
		sortByContinueBias(annotated, details)
	}
	next, ok := pickFirstReady(annotated)
	if !ok {
		h.t.Fatal("pickFirstReady found no ready row")
	}
	return next
}

func (h readyTestHarness) runNextErr(args ...string) error {
	h.t.Helper()
	var stdout bytes.Buffer
	return runWorkable(h.ctx, &stdout, h.ap, args, nextView)
}

func (h readyTestHarness) runNextText(args ...string) string {
	h.t.Helper()
	var stdout bytes.Buffer
	if err := runWorkable(h.ctx, &stdout, h.ap, args, nextView); err != nil {
		h.t.Fatalf("runNext(%v) error = %v", args, err)
	}
	return stdout.String()
}

// `lit next` returns the top of the ready partition: the first open, unblocked
// leaf in the same composite-rank order `lit ready` produces.
func TestRunNextReturnsTopReadyLeaf(t *testing.T) {
	h := newReadyTestHarness(t)
	first := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "First leaf", Topic: "next", IssueType: "task", Priority: 1})
	h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "Second leaf", Topic: "next", IssueType: "task", Priority: 0})

	got := h.runNextRow(false)
	if got.ID != first.ID {
		t.Fatalf("next.ID = %q, want %q (top of ready order)", got.ID, first.ID)
	}
}

// In-progress leaves are not workable starts; `lit next` skips them and returns
// the next open one. The agent should `lit done` an in-progress leaf, not
// `lit start` it again.
func TestRunNextSkipsInProgressLeaf(t *testing.T) {
	h := newReadyTestHarness(t)
	inProgress := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "Already started", Topic: "next", IssueType: "task", Priority: 1})
	if _, err := h.ap.Store.Apply(h.ctx, inProgress.ID, store.Change{Action: model.Start{Assignee: "tester"}, Actor: "tester"}); err != nil {
		t.Fatalf("StartIssue error = %v", err)
	}
	openLeaf := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "Workable", Topic: "next", IssueType: "task", Priority: 0})

	got := h.runNextRow(false)
	if got.ID != openLeaf.ID {
		t.Fatalf("next.ID = %q, want %q (in-progress leaves are not startable)", got.ID, openLeaf.ID)
	}
}

// Blocked leaves (open dependency) are skipped just as `lit ready` partitions
// them out of the ready section. With deterministic creation-order ranking the
// blocker (rank 1, no parent epic, no own dependencies) is unambiguously top,
// so the assertion pins both "dependent skipped" and the exact expected pick.
func TestRunNextSkipsBlockedLeaf(t *testing.T) {
	h := newReadyTestHarness(t)
	blocker := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "Blocker", Topic: "next", IssueType: "task", Priority: 1})
	dependent := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "Dependent", Topic: "next", IssueType: "task", Priority: 0})
	h.addDependency(dependent.ID, blocker.ID)
	h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "Unblocked third", Topic: "next", IssueType: "task", Priority: 0})

	got := h.runNextRow(false)
	if got.ID == dependent.ID {
		t.Fatalf("next.ID = %q (dependent), want a non-blocked leaf", got.ID)
	}
	if got.ID != blocker.ID {
		t.Fatalf("next.ID = %q, want %q (top of ready order after skipping blocked dependent)", got.ID, blocker.ID)
	}
}

// `lit next` exposes the standard narrowing knobs so "the next workable bug"
// is expressible; the filter runs in the shared pipeline, so next answers the
// same narrowed question ready/backlog/queue would.
func TestRunNextTypeFilterPicksMatchingLeaf(t *testing.T) {
	h := newReadyTestHarness(t)
	task := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "Top-ranked task", Topic: "next", IssueType: "task", Priority: 1})
	bug := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "Lower-ranked bug", Topic: "next", IssueType: "bug", Priority: 0})

	text := h.runNextText("--type", "bug")
	if !strings.Contains(text, bug.ID) {
		t.Fatalf("next --type bug output = %q, want %q picked", text, bug.ID)
	}
	if strings.Contains(text, task.ID) {
		t.Fatalf("next --type bug output = %q, want %q filtered out despite outranking the bug", text, task.ID)
	}
}

// --limit and --columns stay off next: a single-row summary has no row count
// or column set to vary, so accepting them would be accepting input the
// command cannot honor.
func TestRunNextRejectsLimitAndColumns(t *testing.T) {
	h := newReadyTestHarness(t)
	for _, args := range [][]string{{"--limit", "2"}, {"--columns", "id"}} {
		err := h.runNextErr(args...)
		if err == nil || !strings.Contains(err.Error(), "unknown flag") {
			t.Fatalf("runNext(%v) error = %v, want unknown-flag usage error", args, err)
		}
	}
}

// No ready work → non-nil error so the calling shell exits non-zero.
// Agents script `lit next` in loops; silent empty success would be a hang.
func TestRunNextErrorsWhenNoReadyWork(t *testing.T) {
	h := newReadyTestHarness(t)
	err := h.runNextErr()
	if err == nil {
		t.Fatal("runNext() error = nil, want non-nil for empty ready set")
	}
	if !strings.Contains(err.Error(), "no ready work") {
		t.Fatalf("runNext() error = %q, want contains \"no ready work\"", err.Error())
	}
}

// `--continue` biases toward leaves whose parent epic derives to in_progress
// (any child started). The composite-rank order would otherwise pick a
// higher-ranked leaf in another epic; --continue keeps the agent in the same
// epic context until it's done.
func TestRunNextContinueBiasesTowardInProgressEpic(t *testing.T) {
	h := newReadyTestHarness(t)
	// epicA gets created first → composite rank places its leaves above epicB's.
	epicA := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "Epic A", Topic: "next", IssueType: "epic", Priority: 1})
	a1 := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "A.1", Topic: "next", IssueType: "task", Priority: 0, ParentID: epicA.ID})
	a2 := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "A.2", Topic: "next", IssueType: "task", Priority: 0, ParentID: epicA.ID})

	epicB := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "Epic B", Topic: "next", IssueType: "epic", Priority: 1})
	b1 := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "B.1", Topic: "next", IssueType: "task", Priority: 0, ParentID: epicB.ID})

	// Start B.1 so epicB derives to in_progress; epicA stays open.
	if _, err := h.ap.Store.Apply(h.ctx, b1.ID, store.Change{Action: model.Start{Assignee: "tester"}, Actor: "tester"}); err != nil {
		t.Fatalf("StartIssue(B.1) error = %v", err)
	}

	// Default order would pick A.1 (top composite rank).
	defaultPick := h.runNextRow(false)
	if defaultPick.ID != a1.ID {
		t.Fatalf("default next = %q, want A.1 %q (composite-rank top)", defaultPick.ID, a1.ID)
	}

	// --continue should skip past A.1/A.2 to find a leaf under in_progress epic B.
	// B.1 is in_progress (skipped); there are no other open leaves under B.
	// So --continue falls back to top-of-queue: A.1.
	// Reframe the test: add B.2 so there is a workable leaf under B. B.2 sits in
	// its own lane so the lane gate does not block it behind the in_progress B.1
	// (an earlier default-lane sibling) — this test's contract is the
	// continue-bias, not lane-gate membership.
	b2 := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "B.2", Topic: "next", IssueType: "task", Priority: 0, ParentID: epicB.ID, Lane: "b2"})
	_ = a2

	continuePick := h.runNextRow(true)
	if continuePick.ID != b2.ID {
		t.Fatalf("--continue next = %q, want B.2 %q (under in_progress epic)", continuePick.ID, b2.ID)
	}
}

// `--continue` with no in-progress epic falls back to the default top-of-queue
// pick — the bias is "prefer if available," not "filter to only".
func TestRunNextContinueFallsBackWhenNoInProgressEpic(t *testing.T) {
	h := newReadyTestHarness(t)
	epicA := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "Epic A", Topic: "next", IssueType: "epic", Priority: 1})
	a1 := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "A.1", Topic: "next", IssueType: "task", Priority: 0, ParentID: epicA.ID})

	got := h.runNextRow(true)
	if got.ID != a1.ID {
		t.Fatalf("--continue with no in-progress epic returned %q, want %q (fallback to top)", got.ID, a1.ID)
	}
}

// A leaf picked by `lit next` carries its parent epic inline so the agent knows
// which epic it would be joining before it claims the leaf.
func TestRunNextCarriesParentEpic(t *testing.T) {
	h := newReadyTestHarness(t)
	epic := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "Container", Topic: "next", IssueType: "epic", Priority: 1})
	leaf := h.createIssue(store.CreateIssueInput{Prefix: "test", Title: "Leaf", Topic: "next", IssueType: "task", Priority: 0, ParentID: epic.ID})

	got := h.runNextRow(false)
	if got.ID != leaf.ID {
		t.Fatalf("next.ID = %q, want %q", got.ID, leaf.ID)
	}
	if got.ParentEpic == nil {
		t.Fatal("next.ParentEpic = nil, want populated for leaf under epic")
	}
	if got.ParentEpic.ID != epic.ID {
		t.Fatalf("next.ParentEpic.ID = %q, want %q", got.ParentEpic.ID, epic.ID)
	}
}
