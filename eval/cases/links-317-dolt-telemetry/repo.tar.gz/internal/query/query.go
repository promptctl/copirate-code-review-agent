package query

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/promptctl/links-issue-tracker/internal/model"
	"github.com/promptctl/links-issue-tracker/internal/store"
)

type ParseResult struct {
	Filter store.ListIssuesFilter
}

func Parse(input string) (ParseResult, error) {
	terms, err := tokenize(strings.TrimSpace(input))
	if err != nil {
		return ParseResult{}, err
	}
	filter := store.ListIssuesFilter{}
	for _, term := range terms {
		if err := applyTerm(&filter, term); err != nil {
			return ParseResult{}, err
		}
	}
	return ParseResult{Filter: filter}, nil
}

func Merge(base store.ListIssuesFilter, incoming store.ListIssuesFilter) (store.ListIssuesFilter, error) {
	filter := base
	normalizedBase, err := normalizeQueryStatuses(filter.Statuses)
	if err != nil {
		return store.ListIssuesFilter{}, err
	}
	normalizedIncoming, err := normalizeQueryStatuses(incoming.Statuses)
	if err != nil {
		return store.ListIssuesFilter{}, err
	}
	filter.Statuses = mergeSlice(normalizedBase, normalizedIncoming)
	// Resolution filtering is OR within the set, so duplicates are absorbed by the
	// allow-map in the store; a plain append needs no dedup.
	filter.Resolutions = append(filter.Resolutions, incoming.Resolutions...)
	filter.IssueTypes = mergeSlice(filter.IssueTypes, incoming.IssueTypes)
	filter.Assignees = mergeSlice(filter.Assignees, incoming.Assignees)
	filter.SearchTerms = append(filter.SearchTerms, incoming.SearchTerms...)
	filter.IDs = append(filter.IDs, incoming.IDs...)
	filter.LabelsAll = append(filter.LabelsAll, incoming.LabelsAll...)
	if err := mergeBoolPointer("has-comments", &filter.HasComments, incoming.HasComments); err != nil {
		return store.ListIssuesFilter{}, err
	}
	if err := mergeTimePointer("updated-after", &filter.UpdatedAfter, incoming.UpdatedAfter); err != nil {
		return store.ListIssuesFilter{}, err
	}
	if err := mergeTimePointer("updated-before", &filter.UpdatedBefore, incoming.UpdatedBefore); err != nil {
		return store.ListIssuesFilter{}, err
	}
	if incoming.Limit > 0 {
		filter.Limit = incoming.Limit
	}
	// [LAW:one-type-per-behavior] Sort keys merge like every other filter slice —
	// flag-supplied keys (base) first, then query-supplied keys, with exact
	// duplicates absorbed — rather than being the lone slice that bypasses the
	// shared dedup-merge. Distinct keys (including same-field/different-direction)
	// stay in order, forming one multi-key ordering.
	filter.SortBy = mergeSlice(filter.SortBy, incoming.SortBy)
	// [LAW:dataflow-not-control-flow] Visibility is monotonic — asking to include
	// archived/deleted from EITHER the flags (base) or the query (incoming)
	// includes them, so the merge is a plain OR with no conflict to detect.
	filter.IncludeArchived = filter.IncludeArchived || incoming.IncludeArchived
	filter.IncludeDeleted = filter.IncludeDeleted || incoming.IncludeDeleted
	return filter, validateFilter(filter)
}

func applyTerm(filter *store.ListIssuesFilter, term string) error {
	switch {
	case strings.HasPrefix(term, "status:"):
		parsed, err := model.ParseState(strings.TrimPrefix(term, "status:"))
		if err != nil {
			return err
		}
		filter.Statuses = append(filter.Statuses, parsed)
		return nil
	case strings.HasPrefix(term, "resolution:"):
		// [LAW:single-enforcer] The sealed resolution set is gated by the one
		// ParseResolution boundary; the query layer reuses it rather than
		// re-listing the members.
		parsed, err := model.ParseResolution(strings.TrimPrefix(term, "resolution:"))
		if err != nil {
			return err
		}
		filter.Resolutions = append(filter.Resolutions, parsed)
		return nil
	case strings.HasPrefix(term, "type:"):
		// [LAW:single-enforcer] The sealed issue-type set is gated by the one
		// ParseIssueType boundary, mirroring the status: and resolution: terms;
		// a typo'd type is an error, never an empty result. [LAW:no-silent-failure]
		parsed, err := model.ParseIssueType(strings.TrimPrefix(term, "type:"))
		if err != nil {
			return err
		}
		filter.IssueTypes = append(filter.IssueTypes, parsed)
		return nil
	case strings.HasPrefix(term, "assignee:"):
		filter.Assignees = append(filter.Assignees, strings.TrimSpace(strings.TrimPrefix(term, "assignee:")))
		return nil
	case strings.HasPrefix(term, "id:"):
		filter.IDs = append(filter.IDs, strings.TrimSpace(strings.TrimPrefix(term, "id:")))
		return nil
	case strings.HasPrefix(term, "label:"):
		filter.LabelsAll = append(filter.LabelsAll, strings.TrimSpace(strings.TrimPrefix(term, "label:")))
		return nil
	case strings.HasPrefix(term, "has:"):
		switch strings.TrimSpace(strings.TrimPrefix(term, "has:")) {
		case "comments":
			value := true
			return mergeBoolPointer("has-comments", &filter.HasComments, &value)
		default:
			return fmt.Errorf("unsupported has: filter %q", term)
		}
	case strings.HasPrefix(term, "sort:"):
		// [LAW:one-source-of-truth] The sort: token and the --sort flag both
		// route through the one store.ParseSortSpecs; the query grammar owns no
		// second copy of the direction syntax.
		specs, err := store.ParseSortSpecs(strings.TrimPrefix(term, "sort:"))
		if err != nil {
			return err
		}
		filter.SortBy = append(filter.SortBy, specs...)
		return nil
	case strings.HasPrefix(term, "limit:"):
		value := strings.TrimSpace(strings.TrimPrefix(term, "limit:"))
		limit, err := strconv.Atoi(value)
		if err != nil {
			// [LAW:no-silent-failure] A non-numeric limit is a typo, never a
			// silent fallback to the uncapped default.
			return fmt.Errorf("limit must be an integer, got %q", value)
		}
		if limit < 0 {
			// [LAW:no-silent-failure] A negative limit is always a typo; without
			// this, Merge's `> 0` guard (and the store's `capLimit`, which treats
			// `<= 0` as uncapped) would swallow it and silently return everything.
			// Zero stays legal — it IS the uncapped default, matching `--limit 0`,
			// so rejecting it would break flag/query parity on a valid value.
			return fmt.Errorf("limit must be non-negative, got %q", value)
		}
		filter.Limit = limit
		return nil
	case term == "archived":
		// Bare visibility keywords mirror the --include-archived/--include-deleted
		// flags: presence flips the bool. [LAW:one-type-per-behavior]
		filter.IncludeArchived = true
		return nil
	case term == "deleted":
		filter.IncludeDeleted = true
		return nil
	case strings.HasPrefix(term, "updated"):
		return applyTimeTerm(filter, strings.TrimPrefix(term, "updated"))
	default:
		filter.SearchTerms = append(filter.SearchTerms, term)
		return nil
	}
}

func normalizeQueryStatuses(statuses []model.State) ([]model.State, error) {
	// [LAW:one-source-of-truth] Preserve nil for "no status filter" so the merged
	// filter matches the flag path's nil rather than diverging as an empty slice —
	// the two grammars must produce byte-identical filters.
	if len(statuses) == 0 {
		return nil, nil
	}
	result := make([]model.State, 0, len(statuses))
	for _, s := range statuses {
		parsed, err := model.ParseState(string(s))
		if err != nil {
			return nil, err
		}
		result = append(result, parsed)
	}
	return result, nil
}

// mergeSlice appends incoming onto base, dropping values base already carries.
// [LAW:one-type-per-behavior] One dedup-merge over every filter slice; the
// element type is the instance, not a reason for a copy.
func mergeSlice[T comparable](base, incoming []T) []T {
	if len(incoming) == 0 {
		return base
	}
	seen := make(map[T]bool, len(base))
	for _, v := range base {
		seen[v] = true
	}
	result := append([]T{}, base...)
	for _, v := range incoming {
		if !seen[v] {
			result = append(result, v)
			seen[v] = true
		}
	}
	return result
}

func applyTimeTerm(filter *store.ListIssuesFilter, expr string) error {
	comparator, value, err := splitComparator(expr)
	if err != nil {
		return fmt.Errorf("parse updated term %q: %w", "updated"+expr, err)
	}
	parsed, err := time.Parse(time.RFC3339, value)
	if err != nil {
		parsed, err = time.Parse(time.RFC3339Nano, value)
		if err != nil {
			return fmt.Errorf("updated timestamp must be RFC3339")
		}
	}
	switch comparator {
	case ">=", ">":
		return mergeTimePointer("updated-after", &filter.UpdatedAfter, &parsed)
	case "<=", "<":
		return mergeTimePointer("updated-before", &filter.UpdatedBefore, &parsed)
	default:
		return fmt.Errorf("updated supports only >=, >, <=, <")
	}
}

func splitComparator(expr string) (string, string, error) {
	value := strings.TrimSpace(expr)
	for _, comparator := range []string{">=", "<=", ">", "<", ":"} {
		if strings.HasPrefix(value, comparator) {
			payload := strings.TrimSpace(strings.TrimPrefix(value, comparator))
			if payload == "" {
				return "", "", fmt.Errorf("missing value")
			}
			return comparator, payload, nil
		}
	}
	return "", "", fmt.Errorf("missing comparator")
}

func tokenize(input string) ([]string, error) {
	if input == "" {
		return nil, nil
	}
	var out []string
	var current strings.Builder
	var quote rune
	for _, r := range input {
		switch {
		case quote != 0:
			if r == quote {
				quote = 0
				continue
			}
			current.WriteRune(r)
		case r == '"' || r == '\'':
			quote = r
		case r == ' ' || r == '\n' || r == '\t':
			if current.Len() > 0 {
				out = append(out, current.String())
				current.Reset()
			}
		default:
			current.WriteRune(r)
		}
	}
	if quote != 0 {
		return nil, fmt.Errorf("unterminated quote in query")
	}
	if current.Len() > 0 {
		out = append(out, current.String())
	}
	return out, nil
}

func validateFilter(filter store.ListIssuesFilter) error {
	if filter.UpdatedAfter != nil && filter.UpdatedBefore != nil && filter.UpdatedAfter.After(*filter.UpdatedBefore) {
		return fmt.Errorf("updated-after cannot be greater than updated-before")
	}
	return nil
}

func mergeBoolPointer(name string, dst **bool, incoming *bool) error {
	if incoming == nil {
		return nil
	}
	if *dst != nil && **dst != *incoming {
		return fmt.Errorf("conflicting %s filters", name)
	}
	if *dst == nil {
		value := *incoming
		*dst = &value
	}
	return nil
}

func mergeTimePointer(name string, dst **time.Time, incoming *time.Time) error {
	if incoming == nil {
		return nil
	}
	if *dst != nil && !(*dst).Equal(*incoming) {
		return fmt.Errorf("conflicting %s filters %s and %s", name, (*dst).Format(time.RFC3339), incoming.Format(time.RFC3339))
	}
	if *dst == nil {
		value := incoming.UTC()
		*dst = &value
	}
	return nil
}
