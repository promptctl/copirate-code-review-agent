package merge

import (
	"encoding/json"
	"testing"
	"time"

	"github.com/promptctl/links-issue-tracker/internal/model"
)

func issueWithStatus(t *testing.T, issue model.Issue, status model.State) model.Issue {
	t.Helper()
	hydrated, err := model.HydrateStatus(issue, model.StatusView{Value: status})
	if err != nil {
		t.Fatalf("HydrateStatus() error = %v", err)
	}
	return hydrated
}

func jsonRoundTripIssue(t *testing.T, issue model.Issue) model.Issue {
	t.Helper()
	data, err := json.Marshal(issue)
	if err != nil {
		t.Fatalf("Marshal() error = %v", err)
	}
	var decoded model.Issue
	if err := json.Unmarshal(data, &decoded); err != nil {
		t.Fatalf("Unmarshal() error = %v", err)
	}
	return decoded
}

func TestThreeWayEmitsProsePendingForConcurrentTitleRewrite(t *testing.T) {
	base := model.Export{Issues: []model.Issue{issueWithStatus(t, model.Issue{ID: "i1", Title: "issue", Priority: 0, IssueType: "task", CreatedAt: time.Now().UTC(), UpdatedAt: time.Now().UTC()}, model.StateOpen)}}
	local := model.Export{Issues: append([]model.Issue(nil), base.Issues...)}
	remote := model.Export{Issues: append([]model.Issue(nil), base.Issues...)}
	local.Issues[0].Title = "local-change"
	remote.Issues[0].Title = "remote-change"

	result := ThreeWay(base, local, remote)
	if len(result.Pending) != 1 {
		t.Fatalf("pending = %#v", result.Pending)
	}
	got := result.Pending[0]
	if got.IssueID != "i1" || got.Field != ProseTitle {
		t.Fatalf("pending ref = %#v", got)
	}
	if got.Base != "issue" || got.Ours != "local-change" || got.Theirs != "remote-change" {
		t.Fatalf("pending texts = %#v", got)
	}
}

// TestThreeWayEmptyBaseUnionsUnrelatedSides pins the load-bearing insight combine relies
// on: with an EMPTY base (no common ancestor), ThreeWay degrades to a two-way union — every
// id on only one side is taken from it, and an id on BOTH is field-resolved with no base. It
// is the whole mechanism of `lit sync reconcile combine`, proven here at the pure boundary.
func TestThreeWayEmptyBaseUnionsUnrelatedSides(t *testing.T) {
	now := time.Now().UTC()
	mk := func(id, title string) model.Issue {
		return issueWithStatus(t, model.Issue{ID: id, Title: title, IssueType: "task", CreatedAt: now, UpdatedAt: now}, model.StateOpen)
	}
	local := model.Export{WorkspaceID: "wsB", Issues: []model.Issue{mk("only-local", "L"), mk("shared", "from-B")}}
	remote := model.Export{WorkspaceID: "wsA", Issues: []model.Issue{mk("only-remote", "R"), mk("shared", "from-A")}}

	result := ThreeWay(model.Export{}, local, remote)
	settled := result.Provisional()

	// The union carries every unique id AND the shared id — nothing dropped.
	got := map[string]bool{}
	for _, issue := range settled.Issues {
		got[issue.ID] = true
	}
	for _, want := range []string{"only-local", "only-remote", "shared"} {
		if !got[want] {
			t.Errorf("union missing %q: %+v", want, settled.Issues)
		}
	}
	// The shared id's title diverged with no base, so it is held for the agent — never picked.
	if len(result.Pending) != 1 {
		t.Fatalf("pending = %#v, want exactly the shared title held", result.Pending)
	}
	p := result.Pending[0]
	if p.IssueID != "shared" || p.Field != ProseTitle || p.Base != "" || p.Ours != "from-B" || p.Theirs != "from-A" {
		t.Fatalf("held prose = %#v, want shared/title with empty base and both sides' text", p)
	}
}

func TestThreeWayComparesJSONUnmarshaledEpicData(t *testing.T) {
	now := time.Now().UTC()
	hydratedEpic, err := model.HydrateAllOf(model.Issue{
		ID:        "epic-1",
		Title:     "base",
		IssueType: "epic",
		CreatedAt: now,
		UpdatedAt: now,
	}, nil)
	if err != nil {
		t.Fatalf("HydrateAllOf() error = %v", err)
	}
	baseIssue := jsonRoundTripIssue(t, hydratedEpic)
	base := model.Export{Issues: []model.Issue{baseIssue}}
	local := model.Export{Issues: []model.Issue{baseIssue}}
	remote := model.Export{Issues: []model.Issue{baseIssue}}
	remote.Issues[0].Title = "remote"

	result := ThreeWay(base, local, remote)
	if len(result.Pending) != 0 {
		t.Fatalf("unexpected pending = %#v", result.Pending)
	}
	if len(result.Provisional().Issues) != 1 || result.Provisional().Issues[0].Title != "remote" {
		t.Fatalf("merged issues = %#v, want remote title", result.Provisional().Issues)
	}
}

func TestIssueEqualTreatsNilAndEmptyLabelsAsEquivalent(t *testing.T) {
	now := time.Now().UTC()
	base := issueWithStatus(t, model.Issue{ID: "i1", Title: "label test", Priority: 0, IssueType: "task", CreatedAt: now, UpdatedAt: now}, model.StateOpen)
	withNil := base
	withNil.Labels = nil
	withEmpty := base
	withEmpty.Labels = []string{}
	if !issueEqual(&withNil, &withEmpty) {
		t.Fatalf("issueEqual(nil, []) = false; nil and empty Labels must compare equal so JSON wire round-trip drift does not synthesize spurious changes")
	}
}

// issueClosedWith builds a closed leaf that is byte-for-byte identical across
// calls except for its resolution — fixed timestamps keep the resolution the
// ONLY varying field, so a detected change can only be the resolution divergence.
func issueClosedWith(t *testing.T, id string, closedAt time.Time, resolution model.Resolution) model.Issue {
	t.Helper()
	fixed := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
	res := resolution
	hydrated, err := model.HydrateStatus(
		model.Issue{ID: id, Title: id, Priority: 0, IssueType: "task", CreatedAt: fixed, UpdatedAt: fixed},
		model.StatusView{Value: model.StateClosed, ClosedAt: &closedAt, Resolution: &res},
	)
	if err != nil {
		t.Fatalf("HydrateStatus() error = %v", err)
	}
	return hydrated
}

// A side that re-closes an already-closed ticket with a DIFFERENT resolution
// (status stays closed, same closed_at) has genuinely moved the row. The
// change-gate must detect it, or ThreeWay routes the side through the
// "unchanged" branch and the new resolution is silently dropped.
func TestIssueChangedDetectsResolutionOnlyDivergence(t *testing.T) {
	closedAt := time.Date(2026, 2, 1, 0, 0, 0, 0, time.UTC)
	base := issueClosedWith(t, "i1", closedAt, model.ResolutionWontfix)
	reResolved := issueClosedWith(t, "i1", closedAt, model.ResolutionDuplicate)
	if !issueChanged(&base, &reResolved) {
		t.Fatalf("issueChanged = false for a resolution-only re-close (wontfix -> duplicate); the edit would be dropped on sync")
	}
}

func TestThreeWayPreservesResolutionOnlyReClose(t *testing.T) {
	closedAt := time.Date(2026, 2, 1, 0, 0, 0, 0, time.UTC)
	baseIssue := issueClosedWith(t, "i1", closedAt, model.ResolutionWontfix)
	base := model.Export{WorkspaceID: "ws", Issues: []model.Issue{baseIssue}}
	// remote leaves the ticket exactly as base; local re-closes with a new reason.
	remote := model.Export{WorkspaceID: "ws", Issues: []model.Issue{baseIssue}}
	local := model.Export{WorkspaceID: "ws", Issues: []model.Issue{issueClosedWith(t, "i1", closedAt, model.ResolutionDuplicate)}}

	result := ThreeWay(base, local, remote)
	if len(result.Pending) != 0 {
		t.Fatalf("unexpected pending = %#v", result.Pending)
	}
	issues := result.Provisional().Issues
	if len(issues) != 1 {
		t.Fatalf("issues = %#v", issues)
	}
	got := issues[0].ResolutionValue()
	if got == nil || *got != model.ResolutionDuplicate {
		t.Fatalf("merged resolution = %v, want duplicate; the lone-side resolution edit must survive the merge", got)
	}
}

func TestThreeWayMergesNonConflictingIssueChanges(t *testing.T) {
	now := time.Now().UTC()
	base := model.Export{
		WorkspaceID: "ws",
		Issues: []model.Issue{
			issueWithStatus(t, model.Issue{ID: "i1", Title: "one", Priority: 0, IssueType: "task", CreatedAt: now, UpdatedAt: now}, model.StateOpen),
			issueWithStatus(t, model.Issue{ID: "i2", Title: "two", Priority: 0, IssueType: "task", CreatedAt: now, UpdatedAt: now}, model.StateOpen),
		},
	}
	local := model.Export{WorkspaceID: base.WorkspaceID, Issues: append([]model.Issue(nil), base.Issues...)}
	local.Issues[0].Title = "local i1"
	remote := model.Export{WorkspaceID: base.WorkspaceID, Issues: append([]model.Issue(nil), base.Issues...)}
	remote.Issues[1].Title = "remote i2"

	result := ThreeWay(base, local, remote)
	if len(result.Pending) != 0 {
		t.Fatalf("unexpected pending = %#v", result.Pending)
	}
	if len(result.Provisional().Issues) != 2 {
		t.Fatalf("issues = %#v", result.Provisional().Issues)
	}
	merged := map[string]string{}
	for _, issue := range result.Provisional().Issues {
		merged[issue.ID] = issue.Title
	}
	if merged["i1"] != "local i1" || merged["i2"] != "remote i2" {
		t.Fatalf("merged titles = %#v", merged)
	}
}

// parentEdges projects parentOf to a child->parent string map for assertions.
func parentEdges(parentOf map[string]model.Relation) map[string]string {
	edges := map[string]string{}
	for child, relation := range parentOf {
		edges[child] = relation.DstID
	}
	return edges
}

// hasParentCycle reports whether following parent edges from any node loops.
func hasParentCycle(edges map[string]string) bool {
	for start := range edges {
		seen := map[string]bool{}
		node := start
		for {
			parent, ok := edges[node]
			if !ok {
				break
			}
			if seen[node] {
				return true
			}
			seen[node] = true
			node = parent
		}
	}
	return false
}

func TestBreakParentCyclesBreaksTailEnteredCycle(t *testing.T) {
	// a -> b -> c -> b: a is a tail feeding a b<->c loop, so the cycle does not
	// begin at whatever node the walk starts from. The victim is the
	// lexicographically greatest child in the loop (c), regardless of walk order.
	parentOf := map[string]model.Relation{
		"a": {SrcID: "a", DstID: "b", Type: model.RelParentChild},
		"b": {SrcID: "b", DstID: "c", Type: model.RelParentChild},
		"c": {SrcID: "c", DstID: "b", Type: model.RelParentChild},
	}
	breakParentCycles(parentOf)
	edges := parentEdges(parentOf)
	if hasParentCycle(edges) {
		t.Fatalf("cycle survived: %#v", edges)
	}
	if _, ok := edges["c"]; ok {
		t.Fatalf("expected c's parent edge deleted as the loop victim, got %#v", edges)
	}
	if edges["a"] != "b" || edges["b"] != "c" {
		t.Fatalf("non-victim edges altered: %#v", edges)
	}
}

func TestBreakParentCyclesBreaksThreeNodeCycle(t *testing.T) {
	// a -> b -> c -> a: a clean 3-cycle. Exactly one edge is removed and the
	// greatest child in the loop (c) is the victim.
	parentOf := map[string]model.Relation{
		"a": {SrcID: "a", DstID: "b", Type: model.RelParentChild},
		"b": {SrcID: "b", DstID: "c", Type: model.RelParentChild},
		"c": {SrcID: "c", DstID: "a", Type: model.RelParentChild},
	}
	breakParentCycles(parentOf)
	edges := parentEdges(parentOf)
	if hasParentCycle(edges) {
		t.Fatalf("cycle survived: %#v", edges)
	}
	if len(edges) != 2 {
		t.Fatalf("expected exactly one edge removed, got %#v", edges)
	}
	if _, ok := edges["c"]; ok {
		t.Fatalf("expected c's parent edge deleted as the loop victim, got %#v", edges)
	}
}
