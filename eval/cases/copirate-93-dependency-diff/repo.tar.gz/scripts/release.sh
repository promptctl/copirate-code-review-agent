#!/usr/bin/env bash
# Publish a release from the current main commit.
#
# This is the single source of the release ritual. [LAW:single-enforcer]
# It is a PUBLISHER, not a bumper: it edits nothing and commits nothing. The
# version bump (package.json + rebuilt dist) lands earlier as a normal PR to
# main; this script tags that merged commit and publishes it. [LAW:decomposition]
#
# Version is read from package.json — the one source of truth. [LAW:one-source-of-truth]
# Run it on a clean, up-to-date main:
#     git checkout main && git pull && ./scripts/release.sh
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"

die() { echo "ERROR: $*" >&2; exit 1; }

# --if-untagged turns an already-released version from a fatal error into a clean
# no-op (exit 0). The manual path takes no flag and dies loudly on a re-release;
# automation (the publish-on-merge workflow) passes --if-untagged so a no-bump push
# exits 0 instead. The outcome is a value the caller passes — the tag-existence
# predicate stays computed only here. [LAW:single-enforcer] [LAW:dataflow-not-control-flow]
IF_UNTAGGED=false
for arg in "$@"; do
  case "$arg" in
    --if-untagged) IF_UNTAGGED=true ;;
    *) die "unknown argument: $arg (usage: release.sh [--if-untagged])" ;;
  esac
done

# --- Preconditions: each fails loudly with a specific cause. [LAW:no-silent-failure] ---
command -v gh   >/dev/null 2>&1 || die "GitHub CLI 'gh' is not installed (https://cli.github.com)."
command -v node >/dev/null 2>&1 || die "node is not installed."
gh auth status  >/dev/null 2>&1 || die "gh is not authenticated. Run: gh auth login"

BRANCH="$(git branch --show-current)"
[ "$BRANCH" = "main" ] || die "release only from main (you are on '$BRANCH')."

git diff --quiet && git diff --cached --quiet \
  || die "working tree is not clean. Release only from an untouched main."

git fetch --quiet origin main
[ "$(git rev-parse @)" = "$(git rev-parse origin/main)" ] \
  || die "local main is not in sync with origin/main. Pull/push so they match, then retry."

[ -d node_modules ] || die "node_modules missing. Run: npm install"

VERSION="$(node -p "require('./package.json').version")"
[ -n "$VERSION" ] || die "could not read version from package.json."
MAJOR="${VERSION%%.*}"

# [LAW:single-enforcer] This action ships ONLY on the v1 line. This script is the one gate that can
# publish, so it is the one place that enforces the policy: refuse any version whose major is not 1.
# A stray major bump in package.json (how 2.0.0 was cut by mistake) can therefore never reach a tag.
# [LAW:no-silent-failure] fail loud, naming the offending version and the fix.
[ "$MAJOR" = "1" ] \
  || die "this action ships only on the v1 line; refusing to release ${VERSION} (major ${MAJOR}). Set package.json back to a 1.x version."

MAJOR_TAG="v${MAJOR}"   # always v1 — guarded above. The moving tag consumers pin. [LAW:dataflow-not-control-flow]

# Immutable tags never move. An existing tag is a fatal mistake on the manual path
# and a clean no-op under --if-untagged; the predicate is checked once, here.
skip_or_die() {
  $IF_UNTAGGED && { echo "✓ version ${VERSION} is already tagged — nothing to release."; exit 0; }
  die "$1"
}
git rev-parse -q --verify "refs/tags/${VERSION}" >/dev/null 2>&1 \
  && skip_or_die "tag ${VERSION} already exists locally. Bump package.json to a new version first."
git ls-remote --exit-code --tags origin "refs/tags/${VERSION}" >/dev/null 2>&1 \
  && skip_or_die "tag ${VERSION} already exists on origin. Bump package.json to a new version first."

# The release gate: the committed dist MUST match a fresh build of src.
# Otherwise the Actions runner (which executes dist/index.js directly) ships
# stale code. Rebuild, diff, and restore the tree either way. [LAW:no-silent-failure]
echo "→ verifying dist matches source (npm run build)…"
npm run build >/dev/null || die "build failed (see the error above)."
if ! git diff --quiet -- dist; then
  git checkout -- dist
  die "dist is out of date with src. Rebuild and commit dist via a PR before releasing."
fi
git checkout -- dist  # discard mtime-only changes; tree returns to clean

REL_SHA="$(git rev-parse --short HEAD)"
echo "✓ releasing ${VERSION} @ ${REL_SHA} (will re-point ${MAJOR_TAG})"

# --- Effects, all at the boundary, in one straight sequence. [LAW:effects-at-boundaries] ---
git tag -a "$VERSION" -m "Release $VERSION"           # immutable, annotated
git tag -f "$MAJOR_TAG" "$VERSION^{}"                 # moving major -> same commit
git push origin "refs/tags/$VERSION"
git push -f origin "refs/tags/$MAJOR_TAG"
gh release create "$VERSION" --verify-tag --title "$VERSION" --generate-notes --latest

echo "✓ released — consumers on @${MAJOR_TAG} now get ${VERSION}"
gh release view "$VERSION" --json url -q .url
